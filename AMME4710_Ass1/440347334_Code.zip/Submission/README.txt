run mainQ1.m for Q1

run mainQ2A.m for the analysis on the seperated lego blocks
will run analysis on all of the images when run

run mainQ2B.m for the analysis on the connected lego blocks
will run analysis on all of the images when run